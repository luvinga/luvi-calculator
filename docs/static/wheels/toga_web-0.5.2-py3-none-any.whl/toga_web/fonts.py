# Fonts are implemented via Pack.__css__, so this class doesn't need to do anything.
class Font:
    def __init__(self, *args, **kwargs):
        pass
